package com.FoodBoxs.android.timeline;

/**
 * Created by RedixbitUser on 3/22/2018.
 */

public enum OrderStatus {
    ACTIVE,INACTIVE,CANCELLED
}