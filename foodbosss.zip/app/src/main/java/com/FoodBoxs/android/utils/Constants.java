package com.FoodBoxs.android.utils;

public class Constants {
    public static final String orderPrepare = "Order is preparing";
    public static final String orderDispatch = "Order is Dispatched";
    public static final String orderDelivered = "Order is Delivered";
}
